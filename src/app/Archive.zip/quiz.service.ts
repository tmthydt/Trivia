import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Router } from "@angular/router";

@Injectable({
  providedIn: "root"
})
export class QuizService {
  userName: any;
  userScore: number = 0;
  userAnswer: any[] = [];
  quizQuestions: any;

  constructor(private http: HttpClient, private router: Router) {}

  // gets questions from SQL DB
  getQuestions() {
    return this.http.get("/api/questions", {
      responseType: "json"
    });
  }

  // sets questions gotten from component to service
  setQuestions(questions) {
    this.quizQuestions = questions;
  }

  // get username and scores from SQL DB
  getScores() {
    return this.http.get("/api/scores", { responseType: "json" });
  }

  // post username and score to SQL DB
  postScores(scoreData) {
    // this.userName = scoreData.userName;
    // console.log("userName: ", this.userName);
    // console.log("Score: ", this.userScore);
    // console.log({ username: this.userName, score: this.userScore });
    console.log(scoreData);

    this.http
      .post("/api/scores", scoreData, { responseType: "json" })
      .subscribe(response => {
        console.log(response);
        this.router.navigate(["/results"]);
      });
  }

  getScoreInfo(form, questions) {
    // console.log(form);
    // console.log(questions);
    let answerArray = Object.values(form.value); // Object.values converts object into an array of strings
    // console.log(Object.values(form.value));
    // console.log(answerArray);
    this.userName = answerArray[0];
    // console.log(this.userName);
    // console.log(questions[0].answer);
    for (let i = 1; i < answerArray.length; i++) {
      if (answerArray[i] === questions[i - 1].answer) {
        // console.log(`Got one right`);
        this.userScore++;
      }
    }
    this.postScores({ username: this.userName, score: this.userScore });
    // console.log(this.userName);
    // console.log(this.userScore);
    // return this.userName, this.userScore;
  }

  // totalResults(scoreData, i) {
  //   console.log(scoreData);
  //   this.userName = scoreData.playerName;
  //   console.log(this.userName);
  //   console.log(this.userScore);
  //   return this.userName;
  //   // console.log(scoreData.playerName);
  //   console.log(scoreData);
  //   console.log(i);

  //   // for (let i = 0; i < scoreData.questions; i++) {
  //   //   console.log(scoreData.questions);
  //   //   //   console.log(i);
  //   // }
  // }

  // // check is choice = answer if so add userScore and place choice into an array
  // checkAnswer(choice, answer, i) {
  //   if (choice === answer) {
  //     this.userScore++;
  //   }
  //   this.userAnswer = [
  //     ...this.userAnswer.slice(0, i),
  //     choice,
  //     ...this.userAnswer.slice(i + 1)
  //   ];
  //   // console.log(answer);
  //   // console.log(choice);
  //   // console.log(this.userScore);
  //   console.log(this.userAnswer);
  //   return this.userScore, this.userAnswer;
  // }

  // getName(nameForm) {
  //   console.log(nameForm);
  // }
}
