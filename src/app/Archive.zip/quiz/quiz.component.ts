import { Component, OnInit } from "@angular/core";
import { QuizService } from "../quiz.service";

@Component({
  selector: "quiz",
  templateUrl: "./quiz.component.html",
  styleUrls: ["./quiz.component.css"]
})
export class QuizComponent implements OnInit {
  quizQuestions: any;
  // userScore: number;

  constructor(private quizService: QuizService) {
    this.quizService.getQuestions().subscribe(response => {
      this.quizQuestions = response;
      this.quizService.setQuestions(response); // send questions generated in component to service
      // console.log(this.quizService.quizQuestions);
    });
  }

  // postScores(scoreData) {
  //   // this.quizService.postScores(scoreData.value);
  //   console.log(scoreData.value);
  // }

  // getName(form) {
  //   this.quizService.getName(form);
  //   console.log(form);
  // }

  getScoreInfo(form) {
    this.quizService.getScoreInfo(form, this.quizQuestions);
  }
  // checkAnswer(choice, answer, i) {
  //   this.quizService.checkAnswer(choice, answer, i);
  // }
  ngOnInit() {}
  //submitAnswer(form){
  // console.log(form.value)
  // }

  //
  // this.service.getScore(form, this.questions)

  // initialArray: any[];
  // initialArray[index]=true;
}
